<?php


namespace Entrecore\GTMetrixClient;

/**
 * Configuration problem exception.
 */
class GTMetrixConfigurationException extends GTMetrixException {

}