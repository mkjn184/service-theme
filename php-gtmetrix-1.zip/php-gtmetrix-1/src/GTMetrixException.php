<?php


namespace Entrecore\GTMetrixClient;

/**
 * Generic GTMetrix exception
 */
class GTMetrixException extends \Exception {

}